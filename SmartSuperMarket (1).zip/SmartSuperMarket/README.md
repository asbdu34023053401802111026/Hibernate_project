# SmartSuperMarket

Supermarket management app: Hibernate 6 + MySQL data layer, Spring Boot REST API, and a single-page web UI.

## Requirements
JDK 17+, Maven 3.8+, MySQL 8 running locally.

## Run
1. Set your MySQL username and password in `src/main/resources/hibernate.cfg.xml`
   (the `smart_supermarket` database and tables are created automatically).
2. Start the app: `mvn spring-boot:run`
3. Open http://localhost:8080

(The original console demo is still available as `com.supermarket.App`.)

## Structure
- `entity` - JPA entities
- `dao` - Hibernate data access classes (these are what the API calls)
- `util/HibernateUtil` - SessionFactory
- `web/ApiController` - REST endpoints under `/api` (categories, suppliers, products, customers, orders)
- `web/WebApplication` - Spring Boot entry point
- `src/main/resources/static` - the web UI (`index.html`, `css/`, `js/`)

Placing an order checks stock, reduces it and calculates the total in one transaction.
